import json
import random
import math
import numpy as np
from collections import Counter

# -----------------------------
# Path to Dataset Files
# -----------------------------
TRAIN_PATH = "train_dataset.json"
VAL_PATH = "valid_dataset.json"
TEST_PATH = "test_dataset.json"

CATEGORY_NAMES = ["car", "truck_bus", "two_wheeler", "pedestrian", "overridable", "underridable"]
FEATURE_NAMES = ["x", "y", "z", "vr", "rcs", "dr", "elevation_angle_fluctuation"]
partition_A_classnames = ["car", "truck_bus", "pedestrian", "overridable"]

RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

def load_json(path):
    with open(path, "r") as f:
        return json.load(f)

def save_json(path, obj):
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)

def get_class_index(onehot):
    """Return index of the '1' in the one-hot vector; robust to float/int values."""
    if not isinstance(onehot, (list, tuple, np.ndarray)):
        raise ValueError("onehot must be a list/tuple/ndarray")
    # Use argmax to handle float representations like 1.0
    return int(np.argmax(onehot))

def compute_class_stats(samples, category_names):
    """
    samples: list of sample dicts (each must contain 'category_onehot' remapped to current partition)
    category_names: list of class names corresponding to indices in the one-hot vectors in `samples`
    """
    counts = Counter()
    for s in samples:
        try:
            idx = get_class_index(s["category_onehot"])
        except Exception:
            # If something is wrong with onehot, skip sample
            continue
        # Defensive: guard against out-of-range index
        if idx < 0 or idx >= len(category_names):
            cls_name = f"unknown_{idx}"
        else:
            cls_name = category_names[idx]
        counts[cls_name] += 1
    # Return ordered dict-like dict
    return dict(counts)

def compute_feature_norm_stats(samples):
    """Compute mean & std for every feature across all objects in all samples."""
    feature_values = {f: [] for f in FEATURE_NAMES}

    for s in samples:
        for obj in s.get("features", []):
            for f in FEATURE_NAMES:
                val = obj.get(f)
                # skip None and NaN
                if val is None:
                    continue
                try:
                    if math.isnan(val):
                        continue
                except Exception:
                    # if not a float, fine
                    pass
                feature_values[f].append(float(val))

    stats_mean = {}
    stats_std = {}

    for f in FEATURE_NAMES:
        values = feature_values[f]
        if len(values) == 0:
            stats_mean[f] = None
            stats_std[f] = None
        else:
            arr = np.array(values, dtype=float)
            stats_mean[f] = float(arr.mean())
            stats_std[f] = float(arr.std(ddof=0))

    return {"mean": stats_mean, "std": stats_std}

def remap_onehot(old_onehot, new_class_map, new_class_count):
    new_vec = [0.0] * new_class_count
    old_idx = get_class_index(old_onehot)
    if old_idx in new_class_map:
        new_vec[new_class_map[old_idx]] = 1.0
    return new_vec

def remap_mask(old_mask, new_class_map, new_class_count):
    new_mask = [0] * new_class_count
    if not isinstance(old_mask, (list, tuple, np.ndarray)):
        # No mask present: return zeros
        return new_mask

    old_len = len(old_mask)
    for old_idx, new_idx in new_class_map.items():
        if 0 <= old_idx < old_len:
            new_mask[new_idx] = old_mask[old_idx]
        else:
            # If old_idx out of bounds, leave default zero
            new_mask[new_idx] = 0
    return new_mask

def partition_dataset(full_data, category_names, partA_names):
    # Defensive checks
    if "data" not in full_data or "metadata" not in full_data:
        raise ValueError("full_data must contain 'metadata' and 'data' keys")

    # Determine class indices for partitions
    partA_idx = [category_names.index(c) for c in partA_names]
    partB_idx = [i for i in range(len(category_names)) if i not in partA_idx]

    # Create index remap for each partition
    partA_map = {old_idx: new_idx for new_idx, old_idx in enumerate(partA_idx)}
    partB_map = {old_idx: new_idx for new_idx, old_idx in enumerate(partB_idx)}

    partA_samples = []
    partB_samples = []

    samples = full_data["data"].copy()
    random.shuffle(samples)

    for sample in samples:
        # defensive get
        old_onehot = sample.get("category_onehot")
        if old_onehot is None:
            continue
        old_idx = get_class_index(old_onehot)

        if old_idx in partA_idx:
            new_onehot = remap_onehot(old_onehot, partA_map, len(partA_idx))
            new_mask = remap_mask(sample.get("obstacle_mask", []), partA_map, len(partA_idx))

            new_sample = dict(sample)  # shallow copy
            new_sample["category_onehot"] = new_onehot
            new_sample["obstacle_mask"] = new_mask
            partA_samples.append(new_sample)

        elif old_idx in partB_idx:
            new_onehot = remap_onehot(old_onehot, partB_map, len(partB_idx))
            new_mask = remap_mask(sample.get("obstacle_mask", []), partB_map, len(partB_idx))

            new_sample = dict(sample)
            new_sample["category_onehot"] = new_onehot
            new_sample["obstacle_mask"] = new_mask
            partB_samples.append(new_sample)

        else:
            # Sample's class not in either partition lists (shouldn't happen), skip
            continue

    metaA = full_data["metadata"].copy()
    metaA["category_names"] = [category_names[i] for i in partA_idx]

    metaB = full_data["metadata"].copy()
    metaB["category_names"] = [category_names[i] for i in partB_idx]

    return (
        {"metadata": metaA, "data": partA_samples},
        {"metadata": metaB, "data": partB_samples},
    )

def print_stats_to_console(name, partA_dict, partB_dict):
    
    metaA = partA_dict.get("metadata", {})
    metaB = partB_dict.get("metadata", {})
    dataA = partA_dict.get("data", [])
    dataB = partB_dict.get("data", [])

    namesA = metaA.get("category_names", [])
    namesB = metaB.get("category_names", [])

    print("\n" + "=" * 70)
    print(f"DATASET STATISTICS: {name.upper()}")
    print("=" * 70)
    print(f"Total Partition A samples: {len(dataA)}")
    print(f"Total Partition B samples: {len(dataB)}\n")

    print("Partition A class distribution:")
    A_stats = compute_class_stats(dataA, namesA)
    for cls, cnt in A_stats.items():
        print(f"  {cls:15s} : {cnt}")

    print("\nPartition B class distribution:")
    B_stats = compute_class_stats(dataB, namesB)
    for cls, cnt in B_stats.items():
        print(f"  {cls:15s} : {cnt}")

    print("=" * 70)

all_statistics = {}

def process_dataset(dataset_path, prefix, dataset_name):
    global all_statistics
    data = load_json(dataset_path)

    partA, partB = partition_dataset(data, CATEGORY_NAMES, partition_A_classnames)

    # Save partitions
    save_json(f"{prefix}_partitionA.json", partA)
    save_json(f"{prefix}_partitionB.json", partB)
    print_stats_to_console(dataset_name, partA, partB)

    stats = {
        "dataset_name": dataset_name,
        "total_partition_A": len(partA["data"]),
        "total_partition_B": len(partB["data"]),
        "class_distribution_A": compute_class_stats(partA["data"], partA["metadata"]["category_names"]),
        "class_distribution_B": compute_class_stats(partB["data"], partB["metadata"]["category_names"]),
        "partitionA_file": f"{prefix}_partitionA.json",
        "partitionB_file": f"{prefix}_partitionB.json",
    }

    # Compute feature norms
    stats["feature_norm_A"] = compute_feature_norm_stats(partA["data"])
    stats["feature_norm_B"] = compute_feature_norm_stats(partB["data"])
    save_json(f"{prefix}_feature_norm_A.json", stats["feature_norm_A"])
    save_json(f"{prefix}_feature_norm_B.json", stats["feature_norm_B"])

    all_statistics[dataset_name] = stats

process_dataset(TRAIN_PATH, "train", "train")
process_dataset(VAL_PATH, "val", "validation")
process_dataset(TEST_PATH, "test", "test")
save_json("statistics.json", all_statistics)

print("\nAll done! Statistics saved to statistics.json")
print("Feature norm files saved as <prefix>_feature_norm_A.json and <prefix>_feature_norm_B.json")

import logging
import numpy as np
import pandas as pd
import tensorflow as tf
from copy import deepcopy
from typing import Tuple, Dict
from tensorflow.keras.models import load_model
from tensorflow import keras
from tensorflow.data import Dataset
import warnings, logging
import matplotlib.pyplot as plt
import json
from sklearn.metrics import confusion_matrix, classification_report
from typing import Tuple, Dict
from copy import deepcopy
from collections import Counter

logger = logging.getLogger(__name__)

class Mask(keras.layers.Layer):
    def __init__(self, **kwargs):
        super(Mask, self).__init__(**kwargs)
        self.__name__ = 'Mask'
 
    def call(self, input_points):
        """A location is invalid, if all features are 0.0. It is valid if any feature is not equal to 0.0."""
        return keras.backend.any(keras.backend.not_equal(input_points, 0.0), axis=-1)
 
    def get_config(self):
        config = super().get_config()
        return config
 
class Repeat(keras.layers.Layer):
    def __init__(self, max_locations, **kwargs):
        super(Repeat, self).__init__(**kwargs)
        self.__name__ = 'Repeat'
        self.max_locations = max_locations
 
    def call(self, inputs):
        return tf.reshape(tensor=keras.backend.repeat(inputs, self.max_locations), shape=(-1, self.max_locations, inputs.shape[1]),)
 
    def get_config(self):
        config = super().get_config()
        config.update({'max_locations': self.max_locations})
        return config
'''
class MaskedGlobalMaxPool1D(keras.layers.Layer):
    def __init__(self, **kwargs):
        super(MaskedGlobalMaxPool1D, self).__init__(**kwargs)
        self.supports_masking = True

    def compute_mask(self, inputs, mask=None):
        # do not propagate mask further
        return None

    def compute_output_shape(self, input_shape):
        return input_shape[:-2] + (input_shape[-1],)

    def call(self, inputs, mask=None):
        # Defensive mask handling ------------------------------------------------
        # If mask is None -> OK, do normal max
        # If mask is something that cannot be converted to a numeric tensor, fall back to deriving a mask from inputs: valid = any(inputs != 0, axis=-1)
        use_mask = None
        if mask is None:
            use_mask = None
        else:
            # Try to convert to tensor first
            try:
                mask_t = tf.convert_to_tensor(mask)
                # If mask is string, try to convert strings to numbers (only if numeric strings)
                if mask_t.dtype == tf.string:
                    # best-effort: convert numeric-strings -> float, else fallback below
                    try:
                        mask_num = tf.strings.to_number(mask_t, out_type=tf.float32)
                        # treat nonzero as True
                        use_mask = tf.cast(mask_num, tf.float32)
                    except Exception:
                        use_mask = None
                else:
                    # numeric-like dtype: cast to float32 for multiplication
                    if mask_t.dtype.is_integer or mask_t.dtype.is_floating or mask_t.dtype == tf.bool:
                        use_mask = tf.cast(mask_t, tf.float32)
                    else:
                        use_mask = None
            except Exception:
                use_mask = None

        if use_mask is None:
            # Fallback: derive mask from inputs: valid location if any feature != 0
            # inputs shape: (batch, time, channels) -> mask shape (batch, time)
            use_mask = tf.cast(tf.reduce_any(tf.not_equal(inputs, tf.constant(0.0, dtype=inputs.dtype)), axis=-1), tf.float32)

        # Apply mask: expand dims to match inputs last axis and multiply
        inputs_masked = inputs * tf.expand_dims(use_mask, axis=-1)

        # Global max over time axis (-2)
        return tf.reduce_max(inputs_masked, axis=-2)
    
'''   
class MaskedGlobalMaxPool1D(keras.layers.Layer): 
    def __init__(self, **kwargs):
        super(MaskedGlobalMaxPool1D, self).__init__(**kwargs)
        self.supports_masking = True
 
    def compute_mask(self, inputs, mask=None):
        # do not further propagate the mask otherwise, we can not use layers such as Dense etc.
        return None
 
    def compute_output_shape(self, input_shape):
        return input_shape[:-2] + (input_shape[-1],)
 
    def call(self, inputs, mask=None):
        if mask is not None:
            mask = keras.backend.cast(mask, keras.backend.floatx())
            # all [False] in mask are zero. This corresponds to an additional ReLu activation function!
            inputs *= keras.backend.expand_dims(mask, axis=-1)
        return keras.backend.max(inputs, axis=-2)

def load_json_as_numpy_dataset(json_path: str) -> Tuple[Dict[str, np.ndarray], Dict]:
   
    with open(json_path, 'r') as f:
        data_json = json.load(f)

    raw_meta = data_json.get("metadata", {})
    data_list = data_json.get("data", [])

    # derive reliable values from actual data
    num_samples = len(data_list)
    if num_samples == 0:
        raise ValueError("No samples found in JSON 'data' array.")

    meta_num_objects = raw_meta.get("num_objects_per_frame", None)
    feature_names = raw_meta.get("feature_names", []) or []
    meta_num_features = raw_meta.get("num_features_per_object", None)

    # Determine actual from first frame (safest)
    first_feats = data_list[0].get("features", [])
    actual_num_objects = len(first_feats)
    if meta_num_objects is None:
        num_objects = actual_num_objects
    else:
        if meta_num_objects != actual_num_objects:
            print(f"WARNING: metadata.num_objects_per_frame ({meta_num_objects}) != actual first frame ({actual_num_objects}). Using actual.")
        num_objects = actual_num_objects

    # Infer feature names / num_features from first object if metadata missing
    if feature_names:
        num_features = len(feature_names)
    else:
        # try infer from keys of first object in first frame
        if actual_num_objects > 0:
            first_obj_keys = list(first_feats[0].keys())
            feature_names = first_obj_keys
            num_features = len(feature_names)
            print(f"INFO: Inferred feature_names = {feature_names}")
        else:
            raise ValueError("Cannot infer feature names: first frame has no objects.")

    # Ensure num_features matches metadata if provided (warn if mismatch)
    if meta_num_features is not None and meta_num_features != num_features:
        print(f"WARNING: metadata.num_features_per_object ({meta_num_features}) != inferred ({num_features}). Using inferred.")

    # Allocate arrays using derived values (fill with NaN for features)
    features = np.full((num_samples, num_objects, num_features), np.nan, dtype=np.float64)
    dr = np.full((num_samples,), np.nan, dtype=np.float64)
    track_index = np.zeros((num_samples,), dtype=np.int32)
    timestamp = np.zeros((num_samples,), dtype=np.float64)
    sample_weight = np.ones((num_samples,), dtype=np.float64)

    # Category onehot and obstacle_mask shapes will be inferred on first occurrence
    category_onehot = None
    obstacle_mask = None

    # Fill arrays frame-by-frame
    for i, frame in enumerate(data_list):
        frame_feats = frame.get("features", [])
        # Build DataFrame to ensure consistent column ordering according to feature_names
        row_list = []
        for obj in frame_feats:
            # create mapping for every feature_name; missing keys -> NaN
            row_list.append({k: (obj.get(k, np.nan) if obj.get(k, None) is not None else np.nan) for k in feature_names})
        # convert to numpy
        if len(row_list) > 0:
            obj_features = pd.DataFrame(row_list, columns=feature_names).to_numpy(dtype=np.float64)
        else:
            # no objects in this frame
            obj_features = np.empty((0, num_features), dtype=np.float64)

        n_obj = obj_features.shape[0]
        # assign (truncate or pad with NaN if necessary)
        if n_obj >= num_objects:
            features[i, :, :] = obj_features[:num_objects, :num_features]
        else:
            features[i, :n_obj, :obj_features.shape[1]] = obj_features

        dr[i] = frame.get("dr", np.nan)
        track_index[i] = frame.get("track_index", 0)
        timestamp[i] = frame.get("timestamp", 0.0)
        sample_weight[i] = frame.get("sample_weight", 1.0)

        # category_onehot: infer width on first non-empty
        co = frame.get("category_onehot", None)
        if co is not None:
            if category_onehot is None:
                category_onehot = np.zeros((num_samples, len(co)), dtype=np.float64)
            if len(co) != category_onehot.shape[1]:
                raise ValueError(f"Inconsistent category_onehot length at frame {i}: {len(co)} != {category_onehot.shape[1]}")
            category_onehot[i, :] = np.array(co, dtype=np.float64)

        # obstacle_mask similar
        om = frame.get("obstacle_mask", None)
        if om is not None:
            if obstacle_mask is None:
                obstacle_mask = np.zeros((num_samples, len(om)), dtype=np.float64)
            if len(om) != obstacle_mask.shape[1]:
                raise ValueError(f"Inconsistent obstacle_mask length at frame {i}: {len(om)} != {obstacle_mask.shape[1]}")
            obstacle_mask[i, :len(om)] = np.array(om, dtype=np.float64)

    if category_onehot is None:
        # create empty 0-column array if no labels present
        category_onehot = np.zeros((num_samples, 0), dtype=np.float64)
    if obstacle_mask is None:
        obstacle_mask = np.zeros((num_samples, category_onehot.shape[1]), dtype=np.float64)

    dataset_np = {"features": features, "dr": dr, "track_index": track_index, "timestamp": timestamp,
        "category_onehot": category_onehot, "sample_weight": sample_weight, "obstacle_mask": obstacle_mask, "feature_names": feature_names}

    metadata_out = {"feature_names": feature_names, "category_names": raw_meta.get("category_names", []),
        "num_samples": num_samples, "num_objects_per_frame": num_objects, "num_features_per_object": num_features}

    return dataset_np, metadata_out

def apply_feature_norm_numpy(dataset: Dict[str, np.ndarray], feature_norm: pd.DataFrame):
    """
    In-place normalize dataset['features'] using feature_norm DataFrame.
    After normalization, dataset['features_normalized'] appears and 'features' is popped.
    """
    feats = dataset['features']
    mean = feature_norm.loc['mean'].to_numpy()
    std = feature_norm.loc['std'].to_numpy()
    dataset['features'] = (feats - mean) / std
    dataset['features_normalized'] = dataset.pop('features')

def prepare_dataset_for_tensorflow(dataset: Dict[str, np.ndarray], feature_norm: pd.DataFrame, batch_size: int, shuffle: bool):
    """
    Returns a batched tf.data.Dataset yielding ((features_dict), labels, sample_weight).
    features_normalized: tf.float32 tensor (N, M, F)
    Other tensors converted to tf.float32 where appropriate.
    """
    dataset_cp = deepcopy(dataset)
    # Normalize (creates 'features_normalized')
    apply_feature_norm_numpy(dataset_cp, feature_norm)

    # Replace object rows that were all-NaN (across features) with zeros
    all_nan = np.all(np.isnan(dataset_cp['features_normalized']), axis=2)
    # Set those object rows to zeros
    # Boolean indexing on first two dims selects rows flattened; assignment shape must match (num_selected, F)
    if np.any(all_nan):
        dataset_cp['features_normalized'][all_nan, :] = 0.0

    # Convert dtypes to float32 for TF
    tensor_features = tf.convert_to_tensor(dataset_cp['features_normalized'], dtype=tf.float64, name='features_normalized')
    tensor_dr = tf.convert_to_tensor(dataset_cp['dr'], dtype=tf.float64, name='dr')
    tensor_track_index = tf.convert_to_tensor(dataset_cp['track_index'], dtype=tf.int32, name='track_index')
    tensor_timestamp = tf.convert_to_tensor(dataset_cp['timestamp'], dtype=tf.float64, name='timestamp')
    tensor_obstacle_mask = tf.convert_to_tensor(dataset_cp['obstacle_mask'], dtype=tf.float64, name='obstacle_mask')
    tensor_labels = tf.convert_to_tensor(dataset_cp['category_onehot'], dtype=tf.float64, name='category_onehot')
    tensor_sample_weight = tf.convert_to_tensor(dataset_cp['sample_weight'], dtype=tf.float64, name='sample_weight')

    # Build dataset of tuples: (feature_dict, labels, sample_weight)
    feature_dict = {
        'features_normalized': tensor_features, 'dr': tensor_dr, 'track_index': tensor_track_index, 'timestamp': tensor_timestamp, 'obstacle_mask': tensor_obstacle_mask}

    dataset_tf = tf.data.Dataset.from_tensor_slices((feature_dict, tensor_labels, tensor_sample_weight))
    if shuffle:
        dataset_tf = dataset_tf.shuffle(buffer_size=tensor_features.shape[0], reshuffle_each_iteration=True)
    batched_dataset_tf = dataset_tf.batch(batch_size).prefetch(2)
    return batched_dataset_tf

def extract_feature_norm():
    with open("Dataset_Path/feature_norm.json", "r") as f:
        data = json.load(f)
    feature_names = data["columns"]
    means = np.array([data["values"]["mean"][col] for col in feature_names])
    stds  = np.array([data["values"]["std"][col]  for col in feature_names])
    feature_norm = pd.DataFrame([means, stds], index=["mean", "std"], columns=feature_names)

    return feature_norm

def inference_tf(model_otc_cfd: keras.Model, dataset_test: Dataset, feature_norm: pd.DataFrame, output_path) -> tuple[np.ndarray, np.ndarray]:
    """
    Runs inference using a TensorFlow model on the provided test dataset.

    Args:
        model_otc_cfd (keras.Model): The tensorflow model to use for inference.
        dataset_test (Dataset): The test dataset.
        feature_norm (pd.DataFrame): Feature means and standard deviations of training data.
        output_path (Path): The path where the output files are saved.

    Returns:
        tuple[np.ndarray, np.ndarray]: Prediction vectors and confidence values.
    """
    dataset_test_tf = prepare_dataset_for_tensorflow(dataset=dataset_test, feature_norm=feature_norm, batch_size=1024,  shuffle=False,)

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        output_values = model_otc_cfd.predict(x=dataset_test_tf, verbose=2, callbacks=[tf.keras.callbacks.ProgbarLogger()],)
        expected_message = (
            "Input dict contained keys ['dr', 'track_index', 'timestamp', 'obstacle_mask'] which did not match "
            'any model input. They will be ignored by the model.'
        )
        if (len(w) != 1 or w[0].category is not UserWarning or w[0].message.args[0] != expected_message):
            raise AssertionError(
                f'When running the model prediction we expect exactly one warning message which '
                f'says `{expected_message}`, but we did not get it. Instead we got:\n{w}'
            )
    
    if isinstance(output_values, list):
        pred_vector = output_values[0]
        confidence = output_values[1]
    elif isinstance(output_values, np.ndarray):
        pred_vector = output_values
        raise AssertionError(
            'Before running the following code line for a not-confid-net you need to that there '
            'is no softmax activation applied to the last layer.'
        )
        # TODO: as this is not in the range of 0-1, maybe we can try applying sigmoid to it
        # confidence = np.nanmax(pred_vector, axis=1) - np.mean(pred_vector, axis=1)

    return pred_vector, confidence

def slightly_biased_equal_distribution(category_names: list[str], biased_category: str, bias: float,) -> np.ndarray:
    """Initializes a numpy vector used as an initialization for a `pred_vector` with an equal distribution which is slightly biased
    towards the `biased_category`. We use this slightly biased equal distribution instead of the unmodified equal distribution, since it
    is not up to the exact implementation of the `argmax()` function, which we usually apply to these prediction vectors, to choose a
    winning category. Instead the slightly `biased_category` is chosen as winning category."""

    # Start with an equal distribution.
    y = np.ones(len(category_names)) / len(category_names)
    # Subtract a fraction of the `bias` from all elements and add `bias` to biased element.
    y -= bias / len(category_names)
    y[category_names.index(biased_category)] += bias
    y = np.round(y, 3)
    x = 1 - sum(y)
    if x > 0:
        y[category_names.index(biased_category)] += x
    return y

#def lowpass_IIR_incl_nan_handling(pred_vector: np.ndarray, confidence: np.ndarray, track: ObjectTrack, filter_coeff: float,
def lowpass_IIR_incl_nan_handling(pred_vector: np.ndarray, confidence: np.ndarray, filter_coeff: float, init_confidence: float = 0.5, 
                                  default_category: str = 'overridable', default_bias: float = 0.005, **_,) -> tuple[np.ndarray, np.ndarray]:
    """
    A simple 1st order IIR Filter.

    NaN handling: If prediction vector contains NaN for any cycle/sample, the IIR filter is not updated and the return values
    contain the same values as in the last cycle, for both prediction vector and confidence.
    Initialization: For example if number of categories is 5 then prediction filter vector is initialized to `[0.199, 0.199, 0.199, 0.204, 0.199]`.
    confidence filter is initialized with `init_confidence`.

    Args:
        pred_vector: activation of the predictions from one track (numpy array, dim0: samples, dim1: classes)
        confidence: confidence of the predictions from one track (numpy array, dim0: samples)
        filter_coeff: IIR filter coefficient
        init_confidence: initialization value for confidence

    Returns:
        pred_vector_filt: filtered activation of the predictions from one track (numpy array, dim0: samples, dim1: classes)
        confidence_filt: filtered confidence of the predictions from one track (numpy array, dim0: samples)
    """

    category_names = ["car", "truck_bus", "two_wheeler", "pedestrian", "overridable", "underridable"]
    # Initialize filter.
    #y_filt = slightly_biased_equal_distribution(track.category_names, default_category, default_bias,)
    y_filt = slightly_biased_equal_distribution(category_names, default_category, default_bias,)
    c_filt = init_confidence
    pred_vector_filt = np.zeros(pred_vector.shape)
    confidence_filt = np.zeros(confidence.shape)

    # Run the filtering.
    for i in range(pred_vector.shape[0]):
        # If the current prediction does not contain any NaN, filtering can be done as usual. 
        # Else no filtering is done and the last filtered values are taken over
        if not np.isnan(pred_vector[i, :]).any():   ## and track.number_of_locations.iloc[i] > 0:
            y_filt = filter_coeff * y_filt + (1 - filter_coeff) * pred_vector[i, :]
            c_filt = filter_coeff * c_filt + (1 - filter_coeff) * confidence[i]
            pred_vector_filt[i, :] = y_filt
            confidence_filt[i] = c_filt
        else:
            # No need to update y_filt and c_filt.
            pred_vector_filt[i, :] = y_filt
            confidence_filt[i] = c_filt

    return pred_vector_filt, confidence_filt

def one_hot_encode(idx: np.ndarray, n_categories: int):
    one_hot_encoded_vectors = np.zeros((idx.size, n_categories))
    one_hot_encoded_vectors[np.arange(idx.size), idx] = 1.0
    return one_hot_encoded_vectors

def softmax(pred_vector: np.ndarray, confidence: np.ndarray, **_) -> tuple[np.ndarray, np.ndarray]:
    """
    ...
    Args:
        pred_vector: activation of the predictions from one track (numpy array, dim0: samples, dim1: classes)
        confidence: confidence of the predictions from one track (numpy array, dim0: samples)
        track: ...

    Returns:
        pred_vector_filt: filtered activation of the predictions from one track (numpy array, dim0: samples, dim1: classes)
    """
    pred_vector = np.exp(pred_vector) / np.exp(pred_vector).sum(axis=1, keepdims=True)
    return pred_vector, confidence

def replace_unconfident(
    pred_vector: np.ndarray, confidence: np.ndarray, threshold: float, strategy: str, default_category: str, **_,) -> tuple[np.ndarray, np.ndarray]:
    """
    Args:
        pred_vector: activation of the predictions from one track (numpy array, dim0: samples, dim1: classes)
        confidence: confidence of the predictions from one track (numpy array, dim0: samples)
        track: ...   I removed the ObjectTrack from the definition and used the fixed values instead.
        threshold: ...{0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7}
        strategy:   'default' or 'last_certain'
            There are two strategies to replace weak classifications:
            1.) Replace weak classifications by a default category
            2.) Replace weak classification by the last certain prediction
                In case option 2 is chosen, 'default_category' is used as initial category.
        default_category: ...'overridable'
    Returns:
        pred_vector: filtered activation of the predictions from one track (numpy array, dim0: samples, dim1: classes)
        confidence: ...
    """

    #default_category_index = track.category_names.index(default_category)
    default_category_index = 4                 ## Fixed it to default_category == 'overridable' as 4
    default_pred_vector = one_hot_encode(np.asarray(default_category_index), 6) # len(track.category_names)), fixed it to 6

    if strategy == 'last_certain':
        last_confident_pred_vector = default_pred_vector
        for i in range(pred_vector.shape[0]):
            if confidence[i] < threshold:
                pred_vector[i, :] = last_confident_pred_vector
            else:
                last_confident_pred_vector = pred_vector[i, :]

    elif strategy == 'default':
        pred_vector[confidence < threshold, :] = default_pred_vector
    else:
        raise NotImplementedError('Unknown `strategy` for `replace_unconfident` postprocessing filter.')
    return pred_vector, confidence

#--------------------------------------------------------------------------------------
## Confusion Matrix Calculation
#--------------------------------------------------------------------------------------
def compute_confusion_matrix(pred_vector, confidence, dataset_category_onehot, class_names=None, return_report=False):
   
    pred_vector = np.asarray(pred_vector)
    # compute predicted indices
    if pred_vector.ndim == 2 and pred_vector.shape[1] > 1:
        y_pred = np.argmax(pred_vector, axis=1)
    elif pred_vector.ndim == 1:
        y_pred = pred_vector.astype(int)
    else:
        raise ValueError("pred_vector must be 1D (indices) or 2D (scores/probs).")

    y_true = np.argmax(np.asarray(dataset_category_onehot), axis=1)

    if not (y_pred.shape[0] == y_true.shape[0] == np.asarray(confidence).squeeze().shape[0]):
        raise ValueError("Mismatch in number of samples between predictions, confidence and y_true.")

    # Decide label set safely: union of labels present in true and pred
    labels_union = np.unique(np.concatenate([np.unique(y_true), np.unique(y_pred)])).tolist()

    # If class_names provided (names for indices 0..C-1), map labels_union -> names for display
    if class_names is not None:
        # map numeric indices to names for row/col labels
        labels_names = [class_names[int(i)] for i in labels_union]
        # produce confusion matrix using sklearn but pass numeric labels_union to avoid mismatch
        raw_cm = confusion_matrix(y_true, y_pred, labels=labels_union)
        cm_df = pd.DataFrame(raw_cm, index=pd.Index(labels_names, name="True"), columns=pd.Index(labels_names, name="Pred"))
    else:
        # use numeric labels as names
        raw_cm = confusion_matrix(y_true, y_pred, labels=labels_union)
        cm_df = pd.DataFrame(raw_cm, index=pd.Index(labels_union, name="True"), columns=pd.Index(labels_union, name="Pred"))

    result = {"confusion_matrix": cm_df, "raw_matrix": raw_cm, "labels_used": labels_union}

    if return_report:
        # classification_report requires label list in same representations passed to it
        if class_names is not None:
            # create string arrays of names for y_true/y_pred mapping
            y_true_names = [class_names[int(i)] for i in y_true]
            y_pred_names = [class_names[int(i)] for i in y_pred]
            # labels for report:
            labels_for_report = labels_names
            report = classification_report(y_true_names, y_pred_names, labels=labels_for_report, output_dict=True, zero_division=0)
        else:
            report = classification_report(y_true, y_pred, labels=labels_union, output_dict=True, zero_division=0)
        result["report"] = report

    # Warning if any expected classes (from class_names) are missing in y_true
    if class_names is not None:
        missing = [class_names[i] for i in range(len(class_names)) if i not in labels_union]
        if missing:
            print("WARNING: These class(es) have zero samples in y_true and will not appear as rows:", missing)

    return result

def save_confusion_matrix_plots(cm_df, save_prefix="confusion_matrix"):
    """
    Plots and saves:
      1. General heatmap of the confusion matrix
      2. Percentage heatmap normalized by rows (per-class accuracy)

    Args:
        cm_df: pandas DataFrame or 2D numpy array
        save_prefix: filename prefix for saved PNG files
    """

    # Convert to DataFrame if needed
    if isinstance(cm_df, np.ndarray):
        cm_df = pd.DataFrame(cm_df)

    labels = cm_df.index.tolist()
    cm = cm_df.values.astype(float)

    # --------------------- 1) RAW CONFUSION MATRIX HEATMAP ---------------------
    plt.figure(figsize=(10, 8))
    plt.imshow(cm, cmap="Blues")   # lighter colormap
    plt.title("Confusion Matrix (Counts)")
    plt.xlabel("Predicted")
    plt.ylabel("True")
    plt.xticks(ticks=np.arange(len(labels)), labels=labels, rotation=45)
    plt.yticks(ticks=np.arange(len(labels)), labels=labels)
    plt.colorbar()

    # Adjust color limits to avoid overly dark colors
    plt.clim(vmin=0, vmax=cm.max())

    # Add numeric values to cells
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            value = cm[i, j]
            # dynamic text color depending on intensity
            text_color = "white" if value > cm.max() * 0.5 else "black"
            plt.text(j, i, f"{int(value)}", ha="center", va="center", color=text_color)

    raw_path = f"output/{save_prefix}_Confusion_Matrix_Count.png"
    plt.savefig(raw_path, dpi=300)
    plt.close()


    # --------------------- 2) PERCENT NORMALIZED HEATMAP -----------------------
    row_sums = cm.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1
    cm_percent = (cm / row_sums) * 100

    plt.figure(figsize=(10, 8))
    plt.imshow(cm_percent, cmap="Greens")   # lighter colormap
    plt.title("Confusion Matrix (Percent)")
    plt.xlabel("Predicted")
    plt.ylabel("True")
    plt.xticks(ticks=np.arange(len(labels)), labels=labels, rotation=45)
    plt.yticks(ticks=np.arange(len(labels)), labels=labels)
    plt.colorbar()

    plt.clim(vmin=0, vmax=100)

    # annotate percentage values
    for i in range(cm_percent.shape[0]):
        for j in range(cm_percent.shape[1]):
            value = cm_percent[i, j]
            text_color = "white" if value > 50 else "black"
            plt.text(j, i, f"{value:.1f}%", ha='center', va='center', color=text_color)

    plt.tight_layout()
    percent_path = f"output/{save_prefix}_Confusion_Matrix_Accuracy.png"
    plt.savefig(percent_path, dpi=300)
    plt.close()

    print(f"Saved: {raw_path}")
    print(f"Saved: {percent_path}")

test_json = "Dataset_Path/test_dataset.json"
dataset_test, test_meta = load_json_as_numpy_dataset(test_json)
y_true = np.argmax(dataset_test["category_onehot"], axis=1)

feature_norm = extract_feature_norm()
output_path = "output/"

index2name = ["car", "truck_bus", "two_wheeler", "pedestrian", "overridable", "underridable"]

threshold=[0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7]

# ------------- Path to our model ------------------
model_path = "Fed_Model/best_global_confidnet.h5"
# -------------- Load the model -----------------
model_otc_cfd = load_model(model_path, custom_objects={'Mask': Mask, 'MaskedGlobalMaxPool1D': MaskedGlobalMaxPool1D, 'Repeat': Repeat})
print(f"Loaded pretrained model from: {model_path}")
#print("Model Architecture: ", model_otc_cfd.summary())

pred_vector, confidence = inference_tf(model_otc_cfd, dataset_test, feature_norm, output_path)

pred_vector_filt, confidence_filt = lowpass_IIR_incl_nan_handling(pred_vector, confidence, filter_coeff=0.97, init_confidence=0.5, default_category='overridable', default_bias=0.005,)

pred_vector, confidence = softmax(pred_vector_filt, confidence_filt)

pred_vector, confidence = replace_unconfident(pred_vector, confidence, threshold=float(0.7), strategy="last_certain", default_category="overridable")

y_pred_indices = np.argmax(pred_vector, axis=1)
print("unique labels in y_true (sorted):", np.sort(np.unique(y_true)))
print("unique labels in y_pred (sorted):", np.sort(np.unique(y_pred_indices)))

print("y_true counts:", dict(Counter(y_true)))
print("y_pred counts:", dict(Counter(y_pred_indices)))

res = compute_confusion_matrix(pred_vector, confidence, dataset_test["category_onehot"], class_names=index2name, return_report=True)
print(res["confusion_matrix"])
print(json.dumps(res["report"], indent=2))
save_confusion_matrix_plots(res["confusion_matrix"], save_prefix="FL_")
